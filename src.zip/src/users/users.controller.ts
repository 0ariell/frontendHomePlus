import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { JwtAuthGuard }                    from '../auth/jwt-auth.guard';
import { UsersService }                    from './users.service';

@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}

  @UseGuards(JwtAuthGuard)
  @Get('profile')
  async profile(@Req() req) {
    return this.usersService.findOne(req.user.sub);
  }
}
