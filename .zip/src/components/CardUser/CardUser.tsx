import React from 'react'
import './CardUser.css'

interface CardUserProps {}

const CardUser: React.FC<CardUserProps> = () => {
  return (
    <div className="carduser">
      CardUser works!
    </div>
  )
}

export default CardUser
