import React from 'react'

const Contact: React.FC = () => {
  return (
    <div className="Contact">
      <h1>Contact Page</h1>
    </div>
  )
}

export default Contact
